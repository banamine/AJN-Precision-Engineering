AJN News Normalizer - Stage 1 (isolated; nothing wired)
Copy into repo root: src/news-normalize/*, package.json, package-lock.json. Then: npm ci && npm run test:news-normalize
Expect: "19 tests passed". Does NOT touch newsDigest.ts, adapter.ts, ajnResourceService.ts, or any existing test.
Adds dependency: entities ^6 (decodeHTMLStrict). Wiring (Stage 2), undated UI (Stage 3), deletions (Stage 4) are NOT included.
