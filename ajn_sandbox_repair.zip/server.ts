import { Readable } from "stream";
import express, { Request, Response } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { buildChannelFromSearch } from "./archive-discovery";
import { getAllGuides, getPlaylistById, ingestM3uPlaylist, getGuideById, getChannelsByGuide, getChannelById, getChannelSources, addChannelSource, getAllPlaylists, syncPlaylist, getScheduleForGuide } from "./guideRegistry";
import { getChannelSchedule } from "./channels";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ARCHIVE_BASE_URL = "https://archive.org";
const UA = "AJN-Precision-Engineering-Proxy/1.0";
const RETRYABLE = new Set([429, 500, 502, 503, 504]);

function validateArchivePath(rawPath: string) {
  if (!rawPath || !rawPath.startsWith("/download/")) {
    return { valid: false, error: "Only Archive.org /download paths are permitted." };
  }
  if (rawPath.includes("..") || rawPath.includes("\\") || rawPath.includes("://")) {
    return { valid: false, error: "Unsafe archive path." };
  }
  return { valid: true, cleanPath: rawPath };
}

app.get("/api/guides", (_req, res) => { const guides = getAllGuides(); res.json({ guides, total: guides.length }); });

app.use(express.json());

app.get('/api/guides/:guideId', (req, res) => { const g = getGuideById(req.params.guideId); if (!g) return res.status(404).json({ error: `Guide not found: ${req.params.guideId}` }); res.json(g); });
app.get('/api/channels', (req, res) => { const guideId = req.query.guide as string | undefined; const channels = getChannelsByGuide(guideId); res.json({ guideId: guideId || 'all', total: channels.length, channels }); });
app.get('/api/channels/:channelId', (req, res) => { const c = getChannelById(req.params.channelId); if (!c) return res.status(404).json({ error: `Channel not found: ${req.params.channelId}` }); res.json(c); });
app.get('/api/channels/:channelId/sources', (req, res) => res.json({ channelId: req.params.channelId, total: getChannelSources(req.params.channelId).length, sources: getChannelSources(req.params.channelId) }));
app.post('/api/channels/:channelId/sources', (req, res) => { const { url, protocol, priority, enabled, metadata } = req.body; if (!url || typeof url !== 'string') return res.status(400).json({ error: 'Source URL is required' }); res.status(201).json({ message: 'Channel source added successfully', source: addChannelSource(req.params.channelId, { url, protocol, priority, enabled, metadata }) }); });
app.get('/api/schedule', async (req, res) => { const guideId = (req.query.guide as string) || 'cable-tv'; try { res.json({ guideId, channels: await getScheduleForGuide(guideId), generatedAt: new Date().toISOString(), source: 'archive.org-live' }); } catch (e) { console.error('[Schedule]', e); res.status(500).json({ error: 'Failed to generate schedule data', channels: [] }); } });
app.get('/api/playlists', (_req, res) => { const playlists = getAllPlaylists(); res.json({ playlists, total: playlists.length }); });
app.get('/api/playlists/:playlistId', (req, res) => { const p = getPlaylistById(req.params.playlistId); if (!p) return res.status(404).json({ error: `Playlist not found: ${req.params.playlistId}` }); res.json(p); });
app.post('/api/playlists/:playlistId/sync', (req, res) => { const r = syncPlaylist(req.params.playlistId, req.body?.customM3u); if (!r.success) return res.status(400).json({ error: `Failed to sync playlist ${req.params.playlistId}`, playlist: r.playlist }); res.json({ message: `Playlist ${req.params.playlistId} synchronized successfully`, playlist: r.playlist, ingestedCount: r.count }); });



app.get("/api/archive/proxy", async (req: Request, res: Response) => {
  const proxyRequestId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString();
  res.setHeader("x-proxy-request-id", proxyRequestId);
  const rawPath = String(req.query.path || "");
  const validation = validateArchivePath(rawPath);
  if (!validation.valid) return res.status(400).json({ error: validation.error });

  const upstreamUrl = `${ARCHIVE_BASE_URL}${validation.cleanPath}`;
  const headers: Record<string, string> = { "User-Agent": UA };
  if (req.headers.range) headers.Range = req.headers.range;
  for (const h of ["if-range", "if-match", "if-none-match", "if-modified-since", "if-unmodified-since"]) {
    if (req.headers[h]) headers[h] = String(req.headers[h]);
  }

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const abortController = new AbortController();
      let fetchTimeout = setTimeout(() => abortController.abort(), 20000);
      const upstream = await fetch(upstreamUrl, {
        headers,
        signal: abortController.signal,
      });
      clearTimeout(fetchTimeout);

      if (upstream.ok || upstream.status === 206) {
        res.status(upstream.status);
        const contentType = upstream.headers.get("content-type");
        if (contentType) res.setHeader("Content-Type", contentType);
        res.setHeader("Accept-Ranges", "bytes");
        for (const h of ["content-length", "content-range", "etag", "last-modified", "cache-control"]) {
          const v = upstream.headers.get(h);
          if (v) res.setHeader(h, v);
        }
        if (upstream.body) {
          const stream = Readable.fromWeb(upstream.body as any);
          stream.on('error', (err) => {
            console.error("[Proxy Stream Error]", err.message);
            if (!res.headersSent) res.status(502).end();
            else if (!res.destroyed) res.destroy();
          });
          req.on('close', () => {
            abortController.abort();
          });
          return stream.pipe(res);
        } else {
          return res.end();
        }
      }

      if (!RETRYABLE.has(upstream.status) || attempt === 3) {
        return res.status(upstream.status).json({ error: `Archive upstream returned ${upstream.status}` });
      }
    } catch (err: any) {
      if (attempt === 3) return res.status(502).json({ error: err?.message || "Archive upstream unavailable" });
    }
    await new Promise(r => setTimeout(r, 750 * 2 ** (attempt - 1)));
  }
});

app.get("/api/archive/metadata", async (req: Request, res: Response) => {
  const rawPath = String(req.query.path || "");
  const validation = validateArchivePath(rawPath);
  if (!validation.valid) return res.status(400).json({ error: validation.error });
  try {
    const r = await fetch(`${ARCHIVE_BASE_URL}${validation.cleanPath}`, { headers: { "User-Agent": UA } });
    res.json({
      status: r.status,
      ok: r.ok,
      contentType: r.headers.get("content-type"),
      contentLength: r.headers.get("content-length"),
      acceptRanges: r.headers.get("accept-ranges"),
      proxyUrl: `/api/archive/proxy?path=${encodeURIComponent(validation.cleanPath)}`
    });
  } catch (err: any) {
    res.status(502).json({ error: err?.message || "Archive unavailable" });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[AJN] Server listening on ${PORT}`);

    // One bounded background build; never fetch every channel in parallel.
    buildChannelFromSearch("collection:SciFi_Horror", "archive-scifi", "Sci-Fi Horror Archive")
      .then(ch => console.log(`[AJN] Archive channel ${ch.name}: ${ch.playlist.length} assets`))
      .catch(err => console.error("[AJN] Archive build failed:", err));

    // News schedule ingestion is intentionally one bounded operation.
    getChannelSchedule().then(schedule => {
      const playlist = getPlaylistById("playlist-news");
      if (!playlist) return;
      let m3u = "#EXTM3U\n";
      for (const ch of schedule) {
        const prog = ch.programs?.[0];
        if (!prog?.archivePath) continue;
        m3u += `#EXTINF:-1 tvg-id="${ch.id}" tvg-name="${ch.name}" group-title="News",${ch.name}\n`;
        m3u += `${prog.archivePath}\n`;
      }
      playlist.rawM3u = m3u;
      ingestM3uPlaylist(playlist, m3u);
      console.log("[AJN] News playlist reingested.");
    }).catch(err => console.error("[AJN] News ingestion failed:", err));
  });
}

startServer();
