import { useCallback, useEffect, useRef, useState } from "react";
import { reportTelemetry } from "./telemetry";
import { NowPlayingMedia } from "./types";
import {
  Play,
  Pause,
  Volume2,
  Volume1,
  VolumeX,
  Maximize,
  Minimize,
  RotateCcw,
  RotateCw,
  Tv,
  CheckCircle2,
} from "lucide-react";
import { useAudioNormalization } from "./use-audio-normalization";
import { useSignalDiagnostics } from "./use-signal-diagnostics";

/**
 * MinimalPlayer — AJN Precision Engineering Canonical Broadcast Player.
 *
 * Architecture & Features:
 * 1. M1 AudioController Singleton:
 *    - useAudioNormalization is the sole owner of AudioContext & createMediaElementSource.
 *    - useSignalDiagnostics consumes the read-only diagnosticsAnalyser tap.
 *    - crossOrigin="anonymous" allows CORS-compliant proxy streams to connect to Web Audio.
 *
 * 2. Phase 2 Continuous TV News Slicing:
 *    - Internet Archive TV News restricts full-file downloads (403 HTML), but provides
 *      clean H.264/AAC MP4 media in 300-second (5-minute) time slices (?start=X&end=Y).
 *    - MinimalPlayer dynamically tracks 300s segment progression across the 1-hour show (12 slices).
 *    - Automatically transitions to the next 5-minute slice at segment boundary.
 *    - Global scrubber spans the entire 60-minute broadcast, dynamically loading and seeking
 *      into the correct 300s slice.
 *
 * 3. Full Precision Controls:
 *    - Play / Pause (toggle with robust autoplay-policy fallback)
 *    - Mute / Unmute & Volume slider (syncs native audio & Web Audio master fader)
 *    - Scrub bar with buffered indicator and time tooltips
 *    - -10s / +10s quick skip
 *    - Fullscreen toggle with fullscreenchange listeners
 *    - Auto-hide controls overlay on idle during playback
 */

interface MinimalPlayerProps {
  src: string;
  title?: string;
  onProgramEnded?: () => void;
  nowPlaying?: NowPlayingMedia;
}

const TV_NEWS_SLICE_SEC = 300; // 5 minutes per Archive.org TV News slice
const TV_NEWS_TOTAL_SEC = 3600; // 60 minutes per standard broadcast block

function formatTime(totalSeconds: number): string {
  if (isNaN(totalSeconds) || totalSeconds < 0) return "00:00";
  const m = Math.floor(totalSeconds / 60);
  const s = Math.floor(totalSeconds % 60);
  const mm = m < 10 ? `0${m}` : `${m}`;
  const ss = s < 10 ? `0${s}` : `${s}`;
  return `${mm}:${ss}`;
}

export default function MinimalPlayer({ src, title, onProgramEnded, nowPlaying }: MinimalPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [statusText, setStatusText] = useState("Loading…");
  const [probesEnabled] = useState(false);
  const [healthScore, setHealthScore] = useState<number | null>(null);

  // Time and continuous segment tracking
  const [isTvNews, setIsTvNews] = useState(false);
  const [baseArchivePath, setBaseArchivePath] = useState("");
  const [currentSegment, setCurrentSegment] = useState(0);
  const [totalSegments, setTotalSegments] = useState(1);
  const [currentOverallTime, setCurrentOverallTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(TV_NEWS_TOTAL_SEC);
  const [activeSrc, setActiveSrc] = useState(src);

  // Controls UI state
  const [showControls, setShowControls] = useState(true);
  const [isDraggingSeek, setIsDraggingSeek] = useState(false);
  const [seekHoverTime, setSeekHoverTime] = useState<number | null>(null);
  const controlsTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingSeekOffsetRef = useRef<number | null>(null);

  // ── M1 AudioController singleton — sole owner of AudioContext/MediaElementSource ──
  const {
    bridgeReady,
    audioCtxRef,
    diagnosticsAnalyserRef,
    diagnosticsReady,
    setMasterVolume,
  } = useAudioNormalization(videoRef, "video", activeSrc);

  // ── Diagnostics consumer — reads the shared tap, owns nothing itself ──
  useSignalDiagnostics({
    videoRef,
    probesEnabled,
    onScore: setHealthScore,
    onMemoryKill: () => {
      console.warn("[MinimalPlayer] Diagnostics memory kill-switch fired");
    },
    onCountdownUpdate: () => {},
    diagnosticsAudioCtx: audioCtxRef.current,
    diagnosticsAnalyser: diagnosticsAnalyserRef.current,
    diagnosticsReady,
  });

  // Parse incoming source and detect TV News segmented broadcasts
  useEffect(() => {
    try {
      const match = src.match(/path=([^&]+)/);
      if (match) {
        const decodedPath = decodeURIComponent(match[1]);
        const tvMatch = decodedPath.match(/(\/download\/[^/?#]+\/[^/?#]+\.mp4)(\?start=(\d+)&end=(\d+))?/i);
        const isTvItem = /[A-Z0-9]+_\d{8}_\d{6}_/i.test(decodedPath) || (tvMatch && tvMatch[2] !== undefined);

        if (isTvItem && tvMatch) {
          const basePath = tvMatch[1];
          const start = tvMatch[3] ? parseInt(tvMatch[3], 10) : 0;
          const initialSegment = Math.floor(start / TV_NEWS_SLICE_SEC);
          const totalSegs = Math.ceil(TV_NEWS_TOTAL_SEC / TV_NEWS_SLICE_SEC);

          setIsTvNews(true);
          setBaseArchivePath(basePath);
          setCurrentSegment(initialSegment);
          setTotalSegments(totalSegs);
          setTotalDuration(TV_NEWS_TOTAL_SEC);
          setCurrentOverallTime(initialSegment * TV_NEWS_SLICE_SEC);

          const constructedPath = `${basePath}?start=${initialSegment * TV_NEWS_SLICE_SEC}&end=${(initialSegment + 1) * TV_NEWS_SLICE_SEC}`;
          setActiveSrc(`/api/archive/proxy?path=${encodeURIComponent(constructedPath)}`);
          return;
        }
      }
    } catch (e) {
      console.warn("[MinimalPlayer] Failed to parse TV slice info:", e);
    }

    // Default standalone media
    setIsTvNews(false);
    setBaseArchivePath("");
    setCurrentSegment(0);
    setTotalSegments(1);
    setActiveSrc(src);
  }, [src]);

  // ── robustPlay — verified autoplay-policy handling ──
  const robustPlay = useCallback((vid: HTMLVideoElement) => {
    vid.play()
      .then(() => {
        setIsPlaying(true);
        setStatusText("Playing");
      })
      .catch((err: unknown) => {
        if (err instanceof DOMException && err.name === "NotAllowedError") {
          vid.muted = true;
          setIsMuted(true);
          vid.play()
            .then(() => {
              setIsPlaying(true);
              setStatusText("Playing (muted — click unmute)");
            })
            .catch(() => {
              setStatusText("Playback blocked — click play to start");
            });
        } else {
          setStatusText(`Playback error: ${err instanceof Error ? err.message : String(err)}`);
        }
      });
  }, []);

  // Reload and connect when activeSrc changes
  useEffect(() => {
    const vid = videoRef.current;
    if (!vid) return;

    setIsPlaying(false);
    setStatusText("Loading…");
    vid.load();

    const onCanPlay = () => {
      if (pendingSeekOffsetRef.current !== null) {
        vid.currentTime = pendingSeekOffsetRef.current;
        pendingSeekOffsetRef.current = null;
      }
      robustPlay(vid);
    };

    const onError = async () => {
      const err = vid.error;
      setStatusText(
        `Failed to load — ${err ? `code ${err.code}: ${err.message || "no message"}` : "upstream error"}`
      );
      
      let httpStatus = null;
      let contentType = null;
      let proxyRequestId = null;
      if (activeSrc) {
        try {
          const head = await fetch(activeSrc, { method: "HEAD" });
          httpStatus = head.status;
          contentType = head.headers.get("content-type");
          proxyRequestId = head.headers.get("x-proxy-request-id");
        } catch (e) {}
      }

      reportTelemetry({
        event: 'media.error',
        guideId: nowPlaying?.guideId || null,
        channelId: nowPlaying?.channelId || null,
        sourceId: nowPlaying?.sourceId || null,
        programId: nowPlaying?.programId || null,
        assetId: nowPlaying?.assetId || null,
        archiveIdentifier: nowPlaying?.archivePath ? nowPlaying.archivePath.split('/')[2] : null,
        mediaPath: nowPlaying?.archivePath || null,
        proxyRequestId,
        httpStatus,
        contentType,
        mediaErrorCode: err?.code || null,
        mediaErrorMessage: err?.message || null,
        readyState: vid.readyState,
        networkState: vid.networkState
      });
    };

    vid.addEventListener("canplay", onCanPlay, { once: true });
    vid.addEventListener("error", onError);

    return () => {
      vid.removeEventListener("canplay", onCanPlay);
      vid.removeEventListener("error", onError);
    };
  }, [activeSrc, robustPlay]);

  // Continuous TV News segment progression handler
  const loadSegment = useCallback((segmentIndex: number, startOffsetInSegment = 0) => {
    if (!baseArchivePath || segmentIndex >= totalSegments || segmentIndex < 0) return;

    setCurrentSegment(segmentIndex);
    pendingSeekOffsetRef.current = startOffsetInSegment;
    const nextStart = segmentIndex * TV_NEWS_SLICE_SEC;
    const nextEnd = (segmentIndex + 1) * TV_NEWS_SLICE_SEC;
    const constructedPath = `${baseArchivePath}?start=${nextStart}&end=${nextEnd}`;
    console.log(`[MinimalPlayer] Loading 5-minute segment ${segmentIndex + 1}/${totalSegments} [${nextStart}s - ${nextEnd}s]`);
    setActiveSrc(`/api/archive/proxy?path=${encodeURIComponent(constructedPath)}`);
  }, [baseArchivePath, totalSegments]);

  // Video time updates and automatic continuous segment transition
  const handleTimeUpdate = () => {
    const vid = videoRef.current;
    if (!vid || isDraggingSeek) return;

    if (isTvNews) {
      const segTime = vid.currentTime;
      const overall = currentSegment * TV_NEWS_SLICE_SEC + segTime;
      setCurrentOverallTime(overall);

      // Auto-advance to next 5-minute segment at boundary
      if (segTime >= TV_NEWS_SLICE_SEC - 0.5 && currentSegment < totalSegments - 1) {
        loadSegment(currentSegment + 1, 0);
      }
    } else {
      setCurrentOverallTime(vid.currentTime);
      if (vid.duration && !isNaN(vid.duration) && vid.duration > 0) {
        setTotalDuration(vid.duration);
      }
    }
  };

  const handleEnded = () => {
    if (isTvNews && currentSegment < totalSegments - 1) {
      loadSegment(currentSegment + 1, 0);
    } else {
      setIsPlaying(false);
      setStatusText("Ended");
      if (onProgramEnded) {
        setTimeout(onProgramEnded, 1500); // 1.5s delay before next asset
      }
    }
  };

  // User interactions: Play / Pause
  const handleTogglePlay = () => {
    const vid = videoRef.current;
    if (!vid) return;
    if (vid.paused || vid.ended) {
      robustPlay(vid);
    } else {
      vid.pause();
      setIsPlaying(false);
      setStatusText("Paused");
    }
  };

  // Mute / Volume controls
  const handleToggleMute = () => {
    const vid = videoRef.current;
    if (!vid) return;
    const newMuted = !vid.muted;
    vid.muted = newMuted;
    setIsMuted(newMuted);
    if (!newMuted && volume === 0) {
      setVolume(0.5);
      vid.volume = 0.5;
      setMasterVolume(0.5);
    }
  };

  const handleVolumeChange = (newVol: number) => {
    const vid = videoRef.current;
    const clamped = Math.max(0, Math.min(1, newVol));
    setVolume(clamped);
    if (vid) {
      vid.volume = clamped;
      if (clamped > 0 && vid.muted) {
        vid.muted = false;
        setIsMuted(false);
      } else if (clamped === 0 && !vid.muted) {
        vid.muted = true;
        setIsMuted(true);
      }
    }
    setMasterVolume(clamped);
  };

  // Seeking across continuous broadcast segments
  const handleSeek = (targetSeconds: number) => {
    const clamped = Math.max(0, Math.min(totalDuration, targetSeconds));
    setCurrentOverallTime(clamped);

    const vid = videoRef.current;
    if (!vid) return;

    if (isTvNews) {
      const targetSeg = Math.min(Math.floor(clamped / TV_NEWS_SLICE_SEC), totalSegments - 1);
      const offsetInSeg = clamped % TV_NEWS_SLICE_SEC;

      if (targetSeg === currentSegment) {
        vid.currentTime = offsetInSeg;
        if (!isPlaying) robustPlay(vid);
      } else {
        loadSegment(targetSeg, offsetInSeg);
      }
    } else {
      vid.currentTime = clamped;
      if (!isPlaying) robustPlay(vid);
    }
  };

  const handleSkip = (seconds: number) => {
    handleSeek(currentOverallTime + seconds);
  };

  // Fullscreen toggle
  const handleToggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch((err) => {
        console.warn("[MinimalPlayer] Fullscreen request failed:", err);
      });
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  useEffect(() => {
    const onFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener("fullscreenchange", onFullscreenChange);
    return () => document.removeEventListener("fullscreenchange", onFullscreenChange);
  }, []);

  // Auto-hide controls overlay
  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        if (!isDraggingSeek) setShowControls(false);
      }, 3000);
    }
  };

  useEffect(() => {
    if (!isPlaying) {
      setShowControls(true);
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    }
  }, [isPlaying]);

  // Keyboard accessibility controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (["INPUT", "TEXTAREA"].includes((e.target as HTMLElement)?.tagName)) return;
      if (e.code === "Space" || e.key === "k") {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.key === "m") {
        e.preventDefault();
        handleToggleMute();
      } else if (e.key === "f") {
        e.preventDefault();
        handleToggleFullscreen();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        handleSkip(-10);
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        handleSkip(10);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  });

  const progressPercent = totalDuration > 0 ? (currentOverallTime / totalDuration) * 100 : 0;

  return (
    <div
      ref={containerRef}
      id="broadcast-player-container"
      onMouseMove={handleMouseMove}
      onMouseLeave={() => isPlaying && setShowControls(false)}
      className="group relative w-full max-w-4xl overflow-hidden rounded-xl border border-neutral-800 bg-neutral-950 shadow-2xl transition-all"
    >
      {/* Title Bar */}
      <div className="flex items-center justify-between border-b border-neutral-800/70 bg-neutral-900/60 px-4 py-2.5 text-xs text-neutral-300">
        <div className="flex items-center gap-2 truncate">
          <Tv className="h-4 w-4 text-sky-400 shrink-0" />
          <span className="truncate font-medium text-neutral-100">{title || "Archive Broadcast Feed"}</span>
        </div>
        <div className="flex items-center gap-2.5 shrink-0 text-[11px]">
          {isTvNews && (
            <span className="rounded bg-sky-950/80 px-2 py-0.5 font-mono text-sky-300 border border-sky-800/50">
              Seg {currentSegment + 1}/{totalSegments} ({formatTime(currentSegment * TV_NEWS_SLICE_SEC)} - {formatTime((currentSegment + 1) * TV_NEWS_SLICE_SEC)})
            </span>
          )}
          {bridgeReady ? (
            <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
              <CheckCircle2 className="h-3.5 w-3.5" /> Audio Bridge OK
            </span>
          ) : (
            <span className="text-neutral-500">Native Audio</span>
          )}
          {healthScore !== null && (
            <span className="font-mono text-neutral-400">Signal: {healthScore}%</span>
          )}
        </div>
      </div>

      {/* Video Viewport */}
      <div className="relative aspect-video w-full bg-black">
        <video
          ref={videoRef}
          src={activeSrc}
          crossOrigin="anonymous"
          playsInline
          className="h-full w-full object-contain"
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onTimeUpdate={handleTimeUpdate}
          onEnded={handleEnded}
          onClick={handleTogglePlay}
        />

        {/* Center Big Play Button (when paused or ended) */}
        {!isPlaying && (
          <div
            onClick={handleTogglePlay}
            className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-[2px] transition-opacity cursor-pointer"
          >
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-sky-500/90 text-white shadow-lg transition-transform hover:scale-110 active:scale-95">
              <Play className="h-8 w-8 translate-x-0.5 fill-current" />
            </div>
          </div>
        )}

        {/* Floating Controls Overlay */}
        <div
          className={`absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-4 transition-opacity duration-300 ${
            showControls || !isPlaying ? "opacity-100" : "pointer-events-none opacity-0"
          }`}
        >
          {/* Interactive Scrubber / Seek Bar */}
          <div className="group/scrub relative mb-3 cursor-pointer py-1">
            <input
              type="range"
              min={0}
              max={totalDuration}
              step={1}
              value={currentOverallTime}
              onMouseDown={() => setIsDraggingSeek(true)}
              onMouseUp={(e) => {
                setIsDraggingSeek(false);
                handleSeek(parseFloat((e.target as HTMLInputElement).value));
              }}
              onTouchStart={() => setIsDraggingSeek(true)}
              onTouchEnd={(e) => {
                setIsDraggingSeek(false);
                handleSeek(parseFloat((e.target as HTMLInputElement).value));
              }}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                setCurrentOverallTime(val);
                if (!isDraggingSeek) handleSeek(val);
              }}
              className="absolute inset-0 z-20 h-full w-full opacity-0 cursor-pointer"
            />
            {/* Track Background */}
            <div className="relative h-1.5 w-full rounded-full bg-neutral-700/80 transition-all group-hover/scrub:h-2.5">
              {/* Progress Bar */}
              <div
                className="absolute top-0 left-0 h-full rounded-full bg-sky-500 transition-all"
                style={{ width: `${progressPercent}%` }}
              />
              {/* Scrubber Handle */}
              <div
                className="absolute top-1/2 -mt-2 -ml-2 h-4 w-4 rounded-full bg-white shadow-md border-2 border-sky-500 transition-transform group-hover/scrub:scale-110"
                style={{ left: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Control Bar Actions */}
          <div className="flex items-center justify-between text-neutral-200">
            {/* Left: Play/Pause, Skip, Volume, Timestamp */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                id="player-play-toggle-btn"
                onClick={handleTogglePlay}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-neutral-800/80 text-white transition hover:bg-neutral-700 hover:text-sky-400"
                title={isPlaying ? "Pause (Space/k)" : "Play (Space/k)"}
              >
                {isPlaying ? <Pause className="h-4 w-4 fill-current" /> : <Play className="h-4 w-4 fill-current translate-x-0.5" />}
              </button>

              <button
                type="button"
                id="player-skip-back-btn"
                onClick={() => handleSkip(-10)}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-neutral-800/80 text-neutral-300 transition hover:bg-neutral-700 hover:text-white"
                title="Rewind 10s (Left Arrow)"
              >
                <RotateCcw className="h-4 w-4" />
              </button>

              <button
                type="button"
                id="player-skip-forward-btn"
                onClick={() => handleSkip(10)}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-neutral-800/80 text-neutral-300 transition hover:bg-neutral-700 hover:text-white"
                title="Forward 10s (Right Arrow)"
              >
                <RotateCw className="h-4 w-4" />
              </button>

              {/* Volume Slider & Toggle */}
              <div className="flex items-center gap-1.5 pl-1">
                <button
                  type="button"
                  id="player-mute-toggle-btn"
                  onClick={handleToggleMute}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-neutral-800/80 text-neutral-300 transition hover:bg-neutral-700 hover:text-white"
                  title={isMuted ? "Unmute (m)" : "Mute (m)"}
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="h-4 w-4 text-rose-400" />
                  ) : volume < 0.5 ? (
                    <Volume1 className="h-4 w-4" />
                  ) : (
                    <Volume2 className="h-4 w-4" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                  className="h-1.5 w-16 accent-sky-500 rounded-full bg-neutral-700 cursor-pointer"
                  title={`Volume: ${Math.round(volume * 100)}%`}
                />
              </div>

              {/* Live Time Display */}
              <div className="ml-2 font-mono text-xs text-neutral-300">
                <span>{formatTime(currentOverallTime)}</span>
                <span className="text-neutral-500"> / </span>
                <span className="text-neutral-400">{formatTime(totalDuration)}</span>
              </div>
            </div>

            {/* Right: Status and Fullscreen */}
            <div className="flex items-center gap-3">
              <span className="hidden sm:inline-block text-xs text-neutral-400">
                {statusText}
              </span>
              <button
                type="button"
                id="player-fullscreen-toggle-btn"
                onClick={handleToggleFullscreen}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-neutral-800/80 text-neutral-300 transition hover:bg-neutral-700 hover:text-white"
                title={isFullscreen ? "Exit Fullscreen (f)" : "Fullscreen (f)"}
              >
                {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

