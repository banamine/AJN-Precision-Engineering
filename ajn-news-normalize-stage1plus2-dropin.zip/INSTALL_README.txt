AJN News Normalizer - Stage 1 + Stage 2 combined. Apply with GOOGLE_BUILDER_INSTALL_NEWS_NORMALIZER_2026-11-07.txt.
Files: src/news-normalize/*(7), src/utils/newsDigest.ts, test-news-digest.ts, package.json, package-lock.json.
