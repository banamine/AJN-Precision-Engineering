AJN status indicators drop-in (rebuilt 2026-10-27 from the owner's local 2026-10-25 files)

NEW FILES - add exactly as they are:
  src/components/StatusIndicators.tsx
  src/utils/serviceStatus.ts
  src/utils/newsReadyStore.ts
  src/utils/archiveOutageRetry.ts
  src/utils/archivePlaybackEvidence.ts
  tools/checks/resume-check.cjs

EDITED FILES - DO NOT overwrite blindly. AI Studio may contain newer edits (for example the
archive.org visible-text removal). For each file, copy in ONLY the status-indicator wiring
(StatusIndicators import/render in Navigation header, removal of the auto Archive banner and
the "Latest news ready" overlay, useArchiveStatus/newsReadyStore usage). Keep every newer
AI Studio change. If a file in AI Studio matches the old version, it may be replaced whole.
  src/App.tsx, src/index.css, src/MinimalPlayer.tsx, src/components/Navigation.tsx,
  src/components/NewsReadyNotice.tsx, src/components/PlayerView.tsx,
  src/hooks/useArchiveStatus.ts, src/utils/playbackFailurePolicy.ts,
  server/archiveHealth.ts, server/archiveHealthProbe.ts, server.ts
  test-archive-health.ts, test-archive-health-server.ts, test-archive-health-ui.tsx,
  test-clear-app-data.ts, test-playback-failure-policy.ts

MUST KEEP in server/archiveHealth.ts: 'unknown' state when there is no evidence; the log filter
that excludes errorCode:null.
DO NOT change any URL, href, src, fetch, proxy route, or isUrlSafe allowlist.
FILES.txt lists the byte size of each file so you can check the copy.
