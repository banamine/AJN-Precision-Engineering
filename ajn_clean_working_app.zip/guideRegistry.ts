import fs from 'fs';
import path from 'path';
import type {
  Guide,
  Channel,
  ChannelSource,
  Program,
  Playlist,
  ScheduleChannel,
  MediaType,
} from './src/types.ts';
import { getChannelSchedule } from './channels.ts';

export const GUIDES: Guide[] = [
  {
    id: 'cable-tv',
    name: 'Cable TV & News',
    type: 'video',
    enabled: true,
    description: '24-Hour Broadcast Television, Live News Feeds, and Network Bulletins',
  },
  {
    id: 'tv-series',
    name: 'Classic TV & Series',
    type: 'video',
    enabled: true,
    description: 'Complete Series: TV Crime Classics, The Sopranos, The Fugitive, The Man From U.N.C.L.E., Total Drama',
  },
  {
    id: 'classic-cinema',
    name: 'Classic Cinema Vault',
    type: 'video',
    enabled: true,
    description: 'Over 100 restored feature films, film noir classics, sci-fi reels, and archival cinema',
  },
  {
    id: 'archive-vault',
    name: 'AJN Archive & Special Feeds',
    type: 'video',
    enabled: true,
    description: '13,000+ Broadcast Episodes: Alex Jones Show, War Room, Daily Highlights, and Tactical Archives',
  },
  {
    id: 'audio-podcasts',
    name: 'Audio & Music Mixer',
    type: 'audio',
    enabled: true,
    description: 'Billboard Hot 100 Hits (with real-time visualizer), LibriVox audiobooks, and Old Time Mystery Radio',
  },
];

export interface ChannelItem {
  title: string;
  url: string;
  duration?: number;
  group?: string;
  logo?: string;
  season?: number;
  episode?: number;
}

const channelsMap = new Map<string, Channel>();
const channelSourcesMap = new Map<string, ChannelSource[]>();
const channelItemsMap = new Map<string, ChannelItem[]>();
const playlistsMap = new Map<string, Playlist>();

// Cached AJN Archive episodes
let ajnArchiveEpisodes: any[] = [];

/**
 * Clean a program or episode title from URL or raw metadata
 */
export function cleanProgramTitle(rawTitle?: string, url?: string): string {
  let t = (rawTitle || '').trim();

  // If title is missing or a placeholder like "Канал 1", "The Sopranos 1", or equal to a URL
  if (
    !t ||
    /^Канал\s+\d+$/i.test(t) ||
    /^Channel\s+\d+$/i.test(t) ||
    /^The\s+Sopranos\s+\d+$/i.test(t) ||
    /^Total\s+Drama\s+Island\s+\d+$/i.test(t) ||
    t.startsWith('http://') ||
    t.startsWith('https://') ||
    t.startsWith('/download/')
  ) {
    if (url) {
      try {
        let pathname = url;
        if (url.startsWith('http://') || url.startsWith('https://')) {
          pathname = new URL(url).pathname;
        }
        const filename = decodeURIComponent(path.basename(pathname)).replace(/\.[^.]+$/, '');
        if (filename) {
          // Remove leading numbers like "034. ", "01 - ", "20181228-"
          t = filename.replace(/^\d+[\.\-_]\s*/, '').trim();
          t = t.replace(/^(\d{8}|\d{6})[\-_]/, '').trim();
        }
      } catch {
        // keep fallback
      }
    }
  }

  // Final sanity check
  return t || 'Featured Broadcast';
}

export interface ParsedM3uEntry {
  title: string;
  url: string;
  tvgId?: string;
  tvgName?: string;
  tvgLogo?: string;
  groupTitle?: string;
  duration?: number;
}

export function parseM3u(text: string): ParsedM3uEntry[] {
  const lines = text.split(/\r?\n/);
  const out: ParsedM3uEntry[] = [];
  let cur: Partial<ParsedM3uEntry> | null = null;

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;

    if (line.startsWith('#EXTINF:')) {
      cur = {};
      const comma = line.lastIndexOf(',');
      let rawTitle = comma >= 0 ? line.slice(comma + 1).trim() : '';

      const matchAttr = (attr: string) =>
        line.match(new RegExp(`${attr}=["']([^"']+)["']`, 'i'))?.[1];

      cur.tvgId = matchAttr('tvg-id');
      cur.tvgName = matchAttr('tvg-name');
      cur.tvgLogo = matchAttr('tvg-logo');
      cur.groupTitle = matchAttr('group-title');

      const durMatch = line.match(/^#EXTINF:(-?\d+)/);
      cur.duration = durMatch ? parseInt(durMatch[1], 10) : 0;
      cur.title = rawTitle;
    } else if (!line.startsWith('#') && cur) {
      cur.url = line;
      cur.title = cleanProgramTitle(cur.title, cur.url);
      out.push(cur as ParsedM3uEntry);
      cur = null;
    }
  }
  return out;
}

export function parsePls(text: string): ParsedM3uEntry[] {
  const lines = text.split(/\r?\n/);
  const entriesMap = new Map<number, Partial<ParsedM3uEntry>>();

  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith('[')) continue;

    const eqIdx = line.indexOf('=');
    if (eqIdx === -1) continue;

    const key = line.slice(0, eqIdx).trim();
    const val = line.slice(eqIdx + 1).trim();

    const fileMatch = key.match(/^File(\d+)$/i);
    const titleMatch = key.match(/^Title(\d+)$/i);
    const lengthMatch = key.match(/^Length(\d+)$/i);

    if (fileMatch) {
      const idx = parseInt(fileMatch[1], 10);
      const e = entriesMap.get(idx) || {};
      e.url = val;
      entriesMap.set(idx, e);
    } else if (titleMatch) {
      const idx = parseInt(titleMatch[1], 10);
      const e = entriesMap.get(idx) || {};
      e.title = val;
      entriesMap.set(idx, e);
    } else if (lengthMatch) {
      const idx = parseInt(lengthMatch[1], 10);
      const e = entriesMap.get(idx) || {};
      e.duration = parseInt(val, 10);
      entriesMap.set(idx, e);
    }
  }

  const out: ParsedM3uEntry[] = [];
  const sortedKeys = Array.from(entriesMap.keys()).sort((a, b) => a - b);
  for (const k of sortedKeys) {
    const item = entriesMap.get(k);
    if (item?.url) {
      item.title = cleanProgramTitle(item.title, item.url);
      out.push(item as ParsedM3uEntry);
    }
  }
  return out;
}

function channelId(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

export function ingestM3uPlaylist(
  playlist: Playlist,
  text: string,
  targetGuideId?: string
) {
  const entries = parseM3u(text);
  const updated: Channel[] = [];
  const guideId =
    targetGuideId ||
    (playlist.category.toLowerCase().includes('audio') ? 'audio-podcasts' : 'cable-tv');
  const mediaType: MediaType = guideId === 'audio-podcasts' ? 'audio' : 'video';

  for (const entry of entries) {
    const id = channelId(entry.tvgId || entry.tvgName || entry.title);
    const existing = channelsMap.get(id);
    const ch: Channel = existing
      ? {
          ...existing,
          logo: existing.logo || entry.tvgLogo,
          group: existing.group || entry.groupTitle || playlist.category,
        }
      : {
          id,
          guideId,
          name: entry.tvgName || entry.title,
          mediaType,
          logo: entry.tvgLogo,
          group: entry.groupTitle || playlist.category,
          tvgId: entry.tvgId,
          tvgName: entry.tvgName,
          enabled: true,
        };

    channelsMap.set(id, ch);
    updated.push(ch);

    const sources = channelSourcesMap.get(id) || [];
    if (!sources.some((s) => s.url === entry.url)) {
      sources.push({
        id: `src-${id}-${sources.length + 1}`,
        channelId: id,
        protocol: entry.url.includes('.m3u8') ? 'hls' : 'https',
        url: entry.url,
        priority: sources.length + 1,
        enabled: true,
        metadata: {
          playlistId: playlist.id,
          playlistName: playlist.name,
          category: playlist.category,
          durationSeconds: entry.duration && entry.duration > 0 ? entry.duration : undefined,
        },
      });
      channelSourcesMap.set(id, sources);
    }
  }

  playlist.lastSyncedAt = new Date().toISOString();
  playlist.syncStatus = 'synced';
  playlist.itemCount = entries.length;
  playlist.rawM3u = text;
  playlistsMap.set(playlist.id, playlist);

  return { ingestedCount: entries.length, channels: updated };
}

/**
 * Register a channel with dedicated items for EPG generation and playback
 */
export function registerChannelWithItems(
  channel: Channel,
  items: ChannelItem[],
  playlistMeta?: Partial<Playlist>
) {
  channelsMap.set(channel.id, channel);
  channelItemsMap.set(channel.id, items);

  const sources: ChannelSource[] = items.slice(0, 10).map((it, idx) => ({
    id: `src-${channel.id}-${idx + 1}`,
    channelId: channel.id,
    protocol: it.url.includes('.m3u8') ? 'hls' : 'https',
    url: it.url,
    title: it.title,
    priority: idx + 1,
    enabled: true,
    metadata: {
      durationSeconds: it.duration,
      group: it.group,
    },
  }));
  channelSourcesMap.set(channel.id, sources);

  if (playlistMeta?.id) {
    const pl: Playlist = {
      id: playlistMeta.id,
      name: playlistMeta.name || channel.name,
      sourceUrl: playlistMeta.sourceUrl || '',
      category: playlistMeta.category || channel.group || 'Archive',
      enabled: true,
      lastSyncedAt: new Date().toISOString(),
      syncStatus: 'synced',
      itemCount: items.length,
    };
    playlistsMap.set(pl.id, pl);
  }
}

/**
 * Load all playlists and metadata from the disk archive
 */
export function initializeRegistry() {
  // 1. Ingest News Channels (Cable TV)
  const newsChannels: Channel[] = [
    {
      id: 'fox-news',
      guideId: 'cable-tv',
      name: 'Fox News Network',
      mediaType: 'video',
      group: 'Live Cable News',
      logo: 'https://archive.org/services/img/FOXNEWSW',
      enabled: true,
    },
    {
      id: 'cnn',
      guideId: 'cable-tv',
      name: 'CNN International',
      mediaType: 'video',
      group: 'Live Cable News',
      logo: 'https://archive.org/services/img/CNNW',
      enabled: true,
    },
    {
      id: 'msnbc',
      guideId: 'cable-tv',
      name: 'MSNBC Live Feed',
      mediaType: 'video',
      group: 'Live Cable News',
      logo: 'https://archive.org/services/img/MSNBCW',
      enabled: true,
    },
    {
      id: 'broadcast-news',
      guideId: 'cable-tv',
      name: 'Broadcast News Special',
      mediaType: 'video',
      group: 'Public Affairs',
      logo: '/images/web app1_thumb.jpg',
      enabled: true,
    },
  ];

  newsChannels.forEach((ch) => {
    channelsMap.set(ch.id, ch);
  });

  // 2. Ingest M3U files from disk dynamically
  const m3uDir = path.join(process.cwd(), 'm3u_files');
  if (fs.existsSync(m3uDir)) {
    const files = fs.readdirSync(m3uDir);
    for (const file of files) {
      if (!file.toLowerCase().endsWith('.m3u')) continue;
      const lower = file.toLowerCase();

      // Handle specialty non-TV feeds explicitly
      if (lower === 'surviv guns infowars.m3u') {
        const survivPath = path.join(m3uDir, file);
        const text = fs.readFileSync(survivPath, 'utf8');
        const entries = parseM3u(text);
        const items: ChannelItem[] = entries.map((e) => ({
          title: e.title,
          url: e.url,
          duration: e.duration || 1200,
          group: 'Tactical & Survival',
          logo: '/images/warroom_thumb.jpg',
        }));
        registerChannelWithItems(
          {
            id: 'surviv-guns',
            guideId: 'archive-vault',
            name: 'Tactical & Survival Vault',
            mediaType: 'video',
            group: 'Specialty Archive',
            logo: '/images/warroom_thumb.jpg',
            enabled: true,
          },
          items,
          { id: 'pl-surviv', name: 'Tactical & Survival Vault', category: 'Archive' }
        );
        continue;
      }

      // Exclude other non-TV or external category feeds from Classic TV
      if (
        lower.includes('ajn') ||
        lower.includes('alex') ||
        lower.includes('infowar') ||
        lower.includes('liberty_express') ||
        lower.includes('veritos') ||
        lower.includes('fact-fake-news') ||
        lower.includes('harvey') ||
        lower.includes('mixer') ||
        lower.includes('billboard') ||
        lower.includes('music') ||
        lower.includes('movies') ||
        lower.includes('bumpers') ||
        lower.includes('eagles') ||
        lower.includes('september 11')
      ) {
        continue;
      }

      // Dynamically load all remaining .m3u files into Classic TV series guide
      const m3uPath = path.join(m3uDir, file);
      try {
        const text = fs.readFileSync(m3uPath, 'utf8');
        const entries = parseM3u(text);
        if (entries.length === 0) continue;

        const baseName = path.basename(file, '.m3u');
        const channelIdStr = `tv-${baseName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
        const playlistIdStr = `pl-${baseName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;

        const items: ChannelItem[] = entries.map((e) => ({
          title: e.title,
          url: e.url,
          duration: e.duration || 3300,
          group: baseName,
          logo: '/images/__ia_thumb.jpg',
        }));

        registerChannelWithItems(
          {
            id: channelIdStr,
            guideId: 'tv-series',
            name: `${baseName} Series`,
            mediaType: 'video',
            group: 'Classic Television',
            logo: '/images/__ia_thumb.jpg',
            enabled: true,
          },
          items,
          { id: playlistIdStr, name: `${baseName} Complete`, category: 'TV Shows' }
        );
      } catch (err) {
        console.error(`[Registry] Error reading M3U file ${file}:`, err);
      }
    }
  }

  // 3. Ingest PLS files (Music Mixer & 9000 Infowars)
  const plsDir = path.join(process.cwd(), 'pls_files');
  if (fs.existsSync(plsDir)) {
    const musicPath = path.join(plsDir, 'music mixer.pls');
    if (fs.existsSync(musicPath)) {
      const text = fs.readFileSync(musicPath, 'utf8');
      const entries = parsePls(text);
      const items: ChannelItem[] = entries.map((e) => ({
        title: e.title,
        url: e.url,
        duration: e.duration || 210,
        group: 'Billboard Hot 100',
        logo: '/images/web app1_thumb.jpg',
      }));
      registerChannelWithItems(
        {
          id: 'music-mixer',
          guideId: 'audio-podcasts',
          name: 'Billboard Hot 100 Radio',
          mediaType: 'audio',
          group: 'Hits Radio & Audio Visualizer',
          logo: '/images/web app1_thumb.jpg',
          enabled: true,
        },
        items,
        { id: 'pl-music-mixer', name: 'Billboard Hot 100 Hits', category: 'Audio & Podcasts' }
      );
    }
  }

  // 4. Ingest Classic Cinema (from tv-player.html)
  const tvPlayerHtmlPath = path.join(process.cwd(), 'other_files', 'tv-player.html');
  if (fs.existsSync(tvPlayerHtmlPath)) {
    try {
      const html = fs.readFileSync(tvPlayerHtmlPath, 'utf8');
      const match = html.match(/var\s+playlist\s*=\s*(\[[\s\S]*?\]);/);
      if (match) {
        const rawList = JSON.parse(match[1]);
        const cinemaItems: ChannelItem[] = [];
        for (const it of rawList) {
          if (it.group?.includes('Classic Movies') || !it.title?.includes('Alex Jones')) {
            cinemaItems.push({
              title: it.title,
              url: it.url,
              duration: it.duration || 6000,
              group: it.group || 'Cinema Classics',
              logo: it['tvg-logo'] || '/images/__ia_thumb.jpg',
            });
          }
        }
        if (cinemaItems.length > 0) {
          registerChannelWithItems(
            {
              id: 'classic-cinema',
              guideId: 'classic-cinema',
              name: 'Cinema Classics Vault',
              mediaType: 'video',
              group: 'Archival & Public Domain Feature Films',
              logo: '/images/__ia_thumb.jpg',
              enabled: true,
            },
            cinemaItems,
            { id: 'pl-cinema', name: 'Classic Cinema Vault', category: 'Movies' }
          );
        }
      }
    } catch (err) {
      console.error('[Registry] Error parsing cinema playlist from tv-player.html:', err);
    }
  }

  // 5. Ingest Audio Vaults (Classic Literature & Mystery Drama)
  const audioDramaItems: ChannelItem[] = [
    {
      title: 'Alice in Wonderland (LibriVox Master Audio)',
      url: '/download/alice_in_wonderland_librivox/wonderland_ch_01.mp3',
      duration: 2700,
      group: 'Audio Drama',
    },
    {
      title: 'Adventures of Sherlock Holmes Audio Vault',
      url: '/download/adventures_holmes/adventureholmes_01_doyle.mp3',
      duration: 3120,
      group: 'Old Time Radio',
    },
    {
      title: 'The Adventures of Tom Sawyer Classic Audio',
      url: '/download/tom_sawyer_librivox/TSawyer_01-02_twain.mp3',
      duration: 2880,
      group: 'American Literature',
    },
    {
      title: 'Moby Dick Unabridged Audio Master',
      url: '/download/moby_dick_librivox/mobydick_000_melville.mp3',
      duration: 3600,
      group: 'Audio Drama',
    },
  ];

  registerChannelWithItems(
    {
      id: 'classic-literature',
      guideId: 'audio-podcasts',
      name: 'Classic Literature & Radio Drama',
      mediaType: 'audio',
      group: 'Audiobooks & Mystery Drama',
      logo: '/images/web app1_thumb.jpg',
      enabled: true,
    },
    audioDramaItems,
    { id: 'pl-audio-literature', name: 'Audio Drama & Classic Literature', category: 'Audio & Podcasts' }
  );

  // 6. Ingest AJN ARCHIVE.json (13,111 episodes)
  const ajnJsonPath = path.join(process.cwd(), 'json_files', 'AJN ARCHIVE.json');
  if (fs.existsSync(ajnJsonPath)) {
    try {
      console.log('[Registry] Loading AJN ARCHIVE.json...');
      const raw = fs.readFileSync(ajnJsonPath, 'utf8');
      const data = JSON.parse(raw);
      ajnArchiveEpisodes = Array.isArray(data.episodes) ? data.episodes : [];
      console.log(`[Registry] Loaded ${ajnArchiveEpisodes.length} episodes from AJN ARCHIVE.json.`);

      // Separate into curated feeds:
      // Alex Jones Show & War Room & Daily Highlights
      const alexItems: ChannelItem[] = [];
      const warRoomItems: ChannelItem[] = [];
      const highlightItems: ChannelItem[] = [];

      for (let i = 0; i < ajnArchiveEpisodes.length; i++) {
        const ep = ajnArchiveEpisodes[i];
        if (!ep?.url) continue;

        const clean = cleanProgramTitle(ep.title, ep.url);
        const item: ChannelItem = {
          title: clean,
          url: ep.url,
          duration: ep.duration && ep.duration > 0 ? ep.duration : 3600,
          group: ep.groupTitle || 'AJN Broadcast Archive',
          logo: ep.tvgLogo || '/images/warroom_thumb.jpg',
          season: ep.season,
          episode: ep.episode,
        };

        const tLower = (ep.title || '').toLowerCase();
        if (tLower.includes('war room') || tLower.includes('warroom')) {
          if (warRoomItems.length < 500) warRoomItems.push(item);
        } else if (tLower.includes('alex jones') || tLower.includes('alex-hr')) {
          if (alexItems.length < 500) alexItems.push(item);
        } else {
          if (highlightItems.length < 500) highlightItems.push(item);
        }
      }

      // If categories are empty, distribute reasonably
      if (alexItems.length === 0) alexItems.push(...highlightItems.slice(0, 200));
      if (warRoomItems.length === 0) warRoomItems.push(...highlightItems.slice(200, 400));

      registerChannelWithItems(
        {
          id: 'alex-jones-show',
          guideId: 'archive-vault',
          name: 'The Alex Jones Show',
          mediaType: 'video',
          group: 'Daily Broadcast Archive',
          logo: '/images/warroom.png',
          enabled: true,
        },
        alexItems,
        { id: 'pl-alex-jones', name: 'The Alex Jones Show Archive', category: 'Archive' }
      );

      registerChannelWithItems(
        {
          id: 'the-war-room',
          guideId: 'archive-vault',
          name: 'The War Room Archive',
          mediaType: 'video',
          group: 'Daily Broadcast Archive',
          logo: '/images/warroom.png',
          enabled: true,
        },
        warRoomItems,
        { id: 'pl-warroom', name: 'The War Room Archive', category: 'Archive' }
      );

      registerChannelWithItems(
        {
          id: 'ajn-highlights',
          guideId: 'archive-vault',
          name: 'AJN Daily Highlights Vault',
          mediaType: 'video',
          group: 'Archival Reports',
          logo: '/images/warroom_thumb.jpg',
          enabled: true,
        },
        highlightItems,
        { id: 'pl-ajn-highlights', name: 'AJN Daily Highlights', category: 'Archive' }
      );
    } catch (err) {
      console.error('[Registry] Error reading AJN ARCHIVE.json:', err);
    }
  }

  console.log(`[Registry] Initialized: ${channelsMap.size} channels across ${GUIDES.length} guides.`);
}

// Auto-initialize on module load
initializeRegistry();

export function getAllGuides(): Guide[] {
  return GUIDES;
}

export function getGuideById(id: string): Guide | undefined {
  return GUIDES.find((g) => g.id === id);
}

export function getChannelsByGuide(guideId?: string): Channel[] {
  return Array.from(channelsMap.values())
    .filter((c) => !guideId || c.guideId === guideId)
    .map((c) => ({
      ...c,
      sources: channelSourcesMap.get(c.id) || [],
    }));
}

export function getChannelById(id: string): Channel | undefined {
  const c = channelsMap.get(id);
  return c ? { ...c, sources: channelSourcesMap.get(id) || [] } : undefined;
}

export function getChannelSources(id: string): ChannelSource[] {
  return channelSourcesMap.get(id) || [];
}

export function getChannelItems(channelId: string, page = 1, limit = 100): { total: number; page: number; limit: number; items: ChannelItem[] } {
  const all = channelItemsMap.get(channelId) || [];
  const start = (page - 1) * limit;
  const paginated = all.slice(start, start + limit);
  return {
    total: all.length,
    page,
    limit,
    items: paginated,
  };
}

export function getAllChannelItems(channelId: string): ChannelItem[] {
  return channelItemsMap.get(channelId) || [];
}

export function getArchiveEpisodes(query?: string, season?: number, page = 1, limit = 50) {
  let filtered = ajnArchiveEpisodes;
  if (query) {
    const qLower = query.toLowerCase();
    filtered = filtered.filter(
      (ep) =>
        ep.title?.toLowerCase().includes(qLower) ||
        ep.tvgName?.toLowerCase().includes(qLower) ||
        ep.id?.toLowerCase().includes(qLower)
    );
  }
  if (season !== undefined) {
    filtered = filtered.filter((ep) => ep.season === season);
  }
  const total = filtered.length;
  const start = (page - 1) * limit;
  const items = filtered.slice(start, start + limit).map((ep) => ({
    id: ep.id,
    title: cleanProgramTitle(ep.title, ep.url),
    url: ep.url,
    season: ep.season,
    episode: ep.episode,
    tvgName: ep.tvgName,
    tvgLogo: ep.tvgLogo,
    duration: ep.duration || 3600,
  }));

  return { total, page, limit, episodes: items };
}

export function addChannelSource(channelId: string, source: Partial<ChannelSource>) {
  const existing = channelSourcesMap.get(channelId) || [];
  const created: ChannelSource = {
    id: source.id || `src-${channelId}-${existing.length + 1}`,
    channelId,
    protocol: source.protocol || (source.url?.includes('.m3u8') ? 'hls' : 'https'),
    url: source.url || '',
    priority: source.priority ?? existing.length + 1,
    enabled: source.enabled ?? true,
    metadata: source.metadata,
  };
  existing.push(created);
  channelSourcesMap.set(channelId, existing);
  return created;
}

export function getAllPlaylists(): Playlist[] {
  return Array.from(playlistsMap.values());
}

export function getPlaylistById(id: string): Playlist | undefined {
  return playlistsMap.get(id);
}

export function syncPlaylist(id: string, customM3u?: string) {
  const p = playlistsMap.get(id);
  if (!p) return { success: false };
  const text = customM3u || p.rawM3u || '';
  if (!text) {
    p.syncStatus = 'failed';
    return { success: false, playlist: p };
  }
  const r = ingestM3uPlaylist(p, text);
  return { success: true, playlist: p, count: r.ingestedCount };
}

/**
 * Generate complete 24-hour EPG schedules for any guide
 */
export async function getScheduleForGuide(guideId = 'cable-tv'): Promise<ScheduleChannel[]> {
  const guide = getGuideById(guideId);
  if (!guide) return [];

  // 1. Cable TV News Networks (uses Archive-backed discovery)
  if (guideId === 'cable-tv') {
    try {
      const news = await getChannelSchedule();
      if (news && news.length > 0) {
        return news.map((ch) => ({
          id: ch.id,
          guideId,
          name: ch.name,
          mediaType: 'video' as MediaType,
          group: 'Cable News',
          logo: `https://archive.org/services/img/${ch.id}`,
          programs: ch.programs.map((p: any, index: number) => ({
            id: `${ch.id}-${index + 1}`,
            guideId,
            channelId: ch.id,
            title: p.title,
            description: `Archive.org broadcast: ${p.title}`,
            startTime: p.startHour,
            endTime: p.endHour,
            startHour: p.startHour,
            endHour: p.endHour,
            mediaType: 'video' as MediaType,
            mediaUrl: p.archivePath,
            archivePath: p.archivePath,
          })),
        }));
      }
    } catch (err) {
      console.warn('[Schedule] News discovery fallback engaged:', err);
    }
  }

  // 2. Series, Cinema, Archive Vault, and Music/Audio Guides
  const channels = getChannelsByGuide(guideId);
  const result: ScheduleChannel[] = [];

  for (const ch of channels) {
    const items = channelItemsMap.get(ch.id) || [];
    const mediaType: MediaType = ch.mediaType || (guide.type as MediaType);
    const programs: Program[] = [];

    if (items.length > 0) {
      // Determine slot length based on category
      // Animation (Total Drama): 0.5 hour (30 min) -> 48 slots
      // Cinema: 2 hours -> 12 slots
      // Drama/Series/News: 1 hour -> 24 slots
      // Music: 1 hour blocks featuring multiple hits or single tracks
      let slotDurationHours = 1.0;
      if (ch.id === 'total-drama') {
        slotDurationHours = 0.5;
      } else if (guideId === 'classic-cinema') {
        slotDurationHours = 2.0;
      }

      const totalSlots = Math.floor(24 / slotDurationHours);

      for (let slot = 0; slot < totalSlots; slot++) {
        const startH = Number((slot * slotDurationHours).toFixed(2));
        const endH = Number(Math.min(24, (slot + 1) * slotDurationHours).toFixed(2));
        const itemIdx = slot % items.length;
        const item = items[itemIdx];

        programs.push({
          id: `${ch.id}-p${slot + 1}`,
          guideId,
          channelId: ch.id,
          title: item.title,
          description: `${ch.name} • ${item.group || ch.group || 'Broadcast Feed'}`,
          startTime: startH,
          endTime: endH,
          startHour: startH,
          endHour: endH,
          mediaType,
          mediaUrl: item.url,
          archivePath: item.url,
          metadata: {
            durationSeconds: item.duration,
            season: item.season,
            episode: item.episode,
          },
        });
      }
    } else {
      // Fallback 24-hour block if no items loaded
      programs.push({
        id: `${ch.id}-full`,
        guideId,
        channelId: ch.id,
        title: ch.name,
        description: `24-Hour Broadcast Stream: ${ch.name}`,
        startTime: 0,
        endTime: 24,
        startHour: 0,
        endHour: 24,
        mediaType,
        mediaUrl: ch.sources?.[0]?.url || '',
        archivePath: ch.sources?.[0]?.url || '',
      });
    }

    result.push({
      id: ch.id,
      guideId,
      name: ch.name,
      mediaType,
      group: ch.group,
      logo: ch.logo,
      programs,
    });
  }

  return result;
}

export function addChannel(ch: Channel) {
  channelsMap.set(ch.id, ch);
}

export function setChannelSources(id: string, sources: ChannelSource[]) {
  channelSourcesMap.set(id, sources);
}
